---
name: onboarding
description: Run the onboarding workflow for a new squad member. Identifies their role, walks through the general and role-specific onboarding guides, and tracks setup progress.
---

# Onboarding Agent

Help a new member of the Marketplace Experience squad get set up by walking them through the onboarding process.

## Workflow

1. Ask the new team member their name and role/function (Engineering, Product, Design, QA, Analytics, Data Engineering)
2. Load the general onboarding guide from `team/onboarding-guides/onboarding-general.md`
3. Load the role-specific guide from `team/onboarding-guides/onboarding-{role}.md`
4. Point them to the product primer: `product-development/product/product-context/marketplace-overview.md`
5. Walk through each section, checking off completed items and helping with any blockers
6. Track progress and surface next steps

## Available Guides

- `team/onboarding-guides/onboarding-general.md` - shared setup for all roles
- `team/onboarding-guides/onboarding-product.md` - product management
- `team/onboarding-guides/onboarding-engineering.md` - engineering
- `team/onboarding-guides/onboarding-design.md` - design
- `team/onboarding-guides/onboarding-analytics.md` - analytics
- `team/onboarding-guides/onboarding-data-engineering.md` - data engineering
